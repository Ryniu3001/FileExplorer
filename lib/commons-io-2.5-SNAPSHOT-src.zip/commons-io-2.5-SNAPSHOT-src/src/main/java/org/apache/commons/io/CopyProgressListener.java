package org.apache.commons.io;

import java.io.File;

/**
 * Created by Marcin on 23.04.2016.
 */
public interface CopyProgressListener {
    void update(long var1, boolean var3, File var4, File var5, String additionalInfo);
}
